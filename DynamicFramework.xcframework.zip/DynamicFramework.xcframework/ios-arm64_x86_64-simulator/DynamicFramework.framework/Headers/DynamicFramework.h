//
//  DynamicFramework.h
//  DynamicFramework
//
//  Created by Boris Bielik on 24/06/2019.
//  Copyright © 2019 BAiOS. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DynamicFramework.
FOUNDATION_EXPORT double DynamicFrameworkVersionNumber;

//! Project version string for DynamicFramework.
FOUNDATION_EXPORT const unsigned char DynamicFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DynamicFramework/PublicHeader.h>


